import React, { useState } from "react";
import { Chess } from "chess.js";

const pieceMap = {
  p: { white: "🟦 Rebel Trooper", black: "🟥 Battle Droid" },
  r: { white: "🟦 Chewbacca", black: "🟥 Stormtrooper" },
  n: { white: "🟦 Han Solo", black: "🟥 Kylo Ren" },
  b: { white: "🟦 Obi-Wan", black: "🟥 Count Dooku" },
  q: { white: "🟦 Yoda", black: "🟥 Palpatine" },
  k: { white: "🟦 Luke", black: "🟥 Vader" },
};

const Square = ({ square, piece, isSelected, onClick }) => (
  <div
    onClick={onClick}
    className={\`w-16 h-16 flex items-center justify-center text-xs text-center border
      \${isSelected ? "bg-yellow-300" : (square.color === "light" ? "bg-gray-200" : "bg-gray-700 text-white")}\`}
  >
    {piece && pieceMap[piece.type][piece.color]}
  </div>
);

export default function StarWarsChess() {
  const [game, setGame] = useState(new Chess());
  const [selectedSquare, setSelectedSquare] = useState(null);

  const board = game.board();

  const handleSquareClick = (row, col) => {
    const square = String.fromCharCode(97 + col) + (8 - row);

    if (selectedSquare) {
      const move = { from: selectedSquare, to: square };
      const result = game.move(move);
      if (result) {
        setGame(new Chess(game.fen()));
        setSelectedSquare(null);
        return;
      }
    }

    const piece = game.get(square);
    if (piece && piece.color === game.turn()) {
      setSelectedSquare(square);
    } else {
      setSelectedSquare(null);
    }
  };

  const resetGame = () => {
    const newGame = new Chess();
    setGame(newGame);
    setSelectedSquare(null);
  };

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">♟️ Star Wars Skak</h1>
      <div className="grid grid-cols-8 border border-black">
        {board.map((row, rowIndex) =>
          row.map((square, colIndex) => {
            const squareColor = (rowIndex + colIndex) % 2 === 0 ? "light" : "dark";
            const squareName = String.fromCharCode(97 + colIndex) + (8 - rowIndex);
            return (
              <Square
                key={squareName}
                square={{ name: squareName, color: squareColor }}
                piece={square}
                isSelected={selectedSquare === squareName}
                onClick={() => handleSquareClick(rowIndex, colIndex)}
              />
            );
          })
        )}
      </div>
      <div className="mt-4">
        <p className="mb-2">Træk: {game.turn() === "w" ? "🟦 Jedi" : "🟥 Sith"}</p>
        <button className="bg-blue-500 text-white px-4 py-2 rounded" onClick={resetGame}>Nulstil spil</button>
      </div>
    </div>
  );
}